# %%
import json
import pandas as pd
from numpy import array

import torch
import torch.nn
import torch.optim as optim

# Used in LTSMModel Class Instantiation
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence

from sklearn.compose import ColumnTransformer
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


# %%
%run data_prep_one_hero.ipynb


# %%
import torch
from torch.utils.data import Dataset

class TimeSeriesDataset(Dataset):
    # Class to create our dataset
    def __init__(self, df, lookback):
        self.hero_ids = df['hero_id'].values # Declaring hero_id values
        self.time_series = df[['gold_t']]
        #[torch.tensor(ts) for ts in df['gold_t']] # Converting the time_series into Tensors
        self.max_length = max(len(ts) for ts in self.time_series) # Grabs max length of all the tensors to pad them with 0s later
        self.match_ids = df['match_id'] #Storing the match_id in case we want to view this later for more info
        self.lookback = lookback


    def __len__(self):
        return len(self.hero_ids) # Convenient length call
    

    def create_windows(self, timeseries):
        X, y = [], []
        for i in range(len(timeseries) - self.lookback):
            feature = timeseries[i:i+self.lookback]
            target = timeseries[i+1:i+self.lookback+1]
            X.append(feature)
            y.append(target)
        
        X = torch.tensor(X)
        y = torch.tensor(y)
        return X, y
    
    

    def __getitem__(self, idx):
        print("1st Step __getitem__ State: ", idx)
        hero_id = self.hero_ids[idx]
        
        time_series = np.array(self.time_series.iloc[idx][0]).astype('float32')  
        match_id = self.match_ids[idx]


        
        scaled_time_series = ConstantMinMaxScaler(time_series, min_gold, max_gold)
        length = len(scaled_time_series)

        X, y = self.create_windows(scaled_time_series)
   
        return hero_id, X, y
 


# %%
import torch
import torch.nn as nn

class ProcessEmbedding(nn.Module):
    def __init__(self, df, embedding_dim, lookback):
        super(ProcessEmbedding, self).__init__() 

        self.num_processes = len(df['hero_id'].unique())
        self.embedding_dim = embedding_dim 
        self.process_embeddings = nn.Embedding(self.num_processes, embedding_dim)

        self.hero_id_to_idx = {hero_id: idx for idx, hero_id in enumerate(df['hero_id'].unique())}

        

    def forward(self, hero_id):
        process_ids = self.hero_id_to_idx[hero_id]
        process_ids = torch.tensor([process_ids])
        process_embeddings = self.process_embeddings(process_ids)

        print("Process Embeddings shape:", process_embeddings.shape)
        print("Process Embeddings tensor:", process_embeddings)

        return process_embeddings



# %%
class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size, process_embedding):
        super(LSTMModel, self).__init__() 

        self.hidden_size = hidden_size
        self.num_layers = num_layers

        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)
        self.process_embedding = process_embedding


    def forward(self, batch):
        print("LSTM Forward Method Batch Type: ",type(batch))

        hero_ids = batch[0][0] 
        X = batch[1][0]
        X = X.unsqueeze(-1) 

        print("LSTM Forward Method X Type: ",type(X))
        print(" LSTM Forward Method - X Shape:", X.shape)
        print("LSTM Forward Method Tensor X",X)
        print("LSTM Forward Method hero_ids Type: ",type(hero_ids))
        print("LSTM Forward Method hero_ids:", hero_ids)
    
        batch_size = X.size(0)
        seq_length = X.size(1) 
        
        print("LSTM Forward Method - batch_size", batch_size)

        process_embeddings = self.process_embedding(hero_ids)

        print("LSTM Forward Method - Process Embeddings Shape Pre-Repeat:", process_embeddings.shape)
        print("LSTM Forward Method - Process Embeddings:", process_embeddings)
        

        process_embeddings = process_embeddings.repeat(batch_size, seq_length, 1) 
        print("LSTM Forward Method - Process Embeddings Shape Post-Repeat:", process_embeddings.shape)

        combined_input = torch.cat((X,process_embeddings),dim=-1) #

        print("Concat'd Time-Series + Embedding shape:", combined_input.shape)


        h0 = torch.zeros(self.num_layers, batch_size, self.hidden_size)
        c0 = torch.zeros(self.num_layers, batch_size, self.hidden_size)
        
        output, _ = self.lstm(combined_input)

        out = self.fc(output[:, -1, :])
        
        return out


# %%
lookback = 10

process_embedding = ProcessEmbedding(df_allhero, embedding_dim=84, lookback=lookback)
input_size = process_embedding.embedding_dim + 1 
hidden_size = 64
num_layers = 2
output_size = 1

model = LSTMModel(input_size, hidden_size, num_layers, output_size, process_embedding)



# %%
batch_size = 1

train_dataset = TimeSeriesDataset(df_allhero, lookback=lookback)
test_dataset = TimeSeriesDataset(df_allhero_avglen, lookback=lookback)

train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=False, collate_fn=lambda x: tuple(zip(*x)))
test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=batch_size, shuffle=False, collate_fn=lambda x: tuple(zip(*x)))



# %%
# Training loop
num_epochs = 500

criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)


for epoch in range(num_epochs):
    model.train()
    
    train_loss = 0.0
    print(f"Epoch: {epoch}")

    for batch in train_loader:     
        hero_ids, X, y = batch 

        X = X[0]

        optimizer.zero_grad()

        # Forward pass
        outputs = model(batch)

        y = y[0]
        print("Training Loop Y Type", type(y))
        print("Training Loop Y shape", len(y))
        print("Training Loop Y", y)

        targets = y[:, -1] 
        loss = criterion(outputs.squeeze(), targets.squeeze())

        loss.backward()
        optimizer.step()

        train_loss += loss.item() * X.size(0)

    train_loss /= len(train_dataset)

    model.eval()
    test_loss = 0.0

    with torch.no_grad():
         for batch in test_loader:
            # Forward pass
            hero_ids, X, y = batch
            X = X[0]
            y = y[0]
            outputs = model(batch)
            targets = y[:, -1] 
            loss = criterion(outputs.squeeze(), targets.squeeze())

            test_loss += loss.item() * X.size(0)

    test_loss /= len(test_dataset)

    print(f"Epoch [{epoch+1}/{num_epochs}], Train Loss: {train_loss:.4f}, Test Loss: {test_loss:.4f}")


